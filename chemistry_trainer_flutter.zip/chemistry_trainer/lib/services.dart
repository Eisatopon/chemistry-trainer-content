import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

// ============================================================
// CONTENT SERVICE — fetch JSON από GitHub Pages
// ============================================================
class ContentService {
  static const String baseUrl =
      'https://eisatopon.github.io/chemistry-trainer-content';

  static Future<List<Chapter>> fetchChapters() async {
    final response = await http.get(Uri.parse('$baseUrl/index.json'));
    if (response.statusCode == 200) {
      final data = json.decode(utf8.decode(response.bodyBytes));
      return (data['chapters'] as List)
          .map((c) => Chapter.fromJson(c))
          .toList();
    }
    throw Exception('Αποτυχία φόρτωσης κεφαλαίων');
  }

  static Future<List<Question>> fetchQuestions(String file) async {
    final response = await http.get(Uri.parse('$baseUrl/$file'));
    if (response.statusCode == 200) {
      final data = json.decode(utf8.decode(response.bodyBytes));
      return (data['questions'] as List)
          .map((q) => Question.fromJson(q))
          .toList();
    }
    throw Exception('Αποτυχία φόρτωσης ερωτήσεων');
  }
}

// ============================================================
// PROGRESS SERVICE — αποθήκευση προόδου τοπικά
// ============================================================
class ProgressService {
  static Future<void> saveResult(QuizResult result) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'result_${result.chapterId}';
    final data = json.encode({
      'correct': result.correctAnswers,
      'wrong': result.wrongAnswers,
      'total': result.totalQuestions,
      'date': result.completedAt.toIso8601String(),
    });
    await prefs.setString(key, data);
  }

  static Future<QuizResult?> loadResult(String chapterId, int total) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('result_$chapterId');
    if (raw == null) return null;
    final data = json.decode(raw);
    return QuizResult(
      chapterId: chapterId,
      totalQuestions: total,
      correctAnswers: data['correct'],
      wrongAnswers: data['wrong'],
      completedAt: DateTime.parse(data['date']),
    );
  }

  static Future<void> clearResult(String chapterId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('result_$chapterId');
  }
}
