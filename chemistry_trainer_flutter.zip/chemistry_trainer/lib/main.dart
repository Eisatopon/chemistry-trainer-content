import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(const ChemistryTrainerApp());
}

class ChemistryTrainerApp extends StatelessWidget {
  const ChemistryTrainerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Χημεία Πανελλαδικών',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.gold,
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const HomeScreen(),
    );
  }
}

// ============================================================
// ΧΡΩΜΑΤΑ από το εξώφυλλο του βιβλίου Χημείας
// ============================================================
class AppColors {
  // Κύριο χρυσοκίτρινο φόντο
  static const Color background = Color(0xFFC9A84C);
  // Ανοιχτό χρυσό (φόντο cards)
  static const Color cardBg = Color(0xFFDDBE6A);
  // Σκούρο καφέ (footer, headers)
  static const Color dark = Color(0xFF7A5C1E);
  // Πιο σκούρο καφέ (text)
  static const Color darkText = Color(0xFF4A3510);
  // Χρυσό τίτλου
  static const Color gold = Color(0xFFE8B84B);
  // Ανοιχτό μπεζ
  static const Color lightBeige = Color(0xFFF2DFA0);
  // Λευκό
  static const Color white = Color(0xFFFFFFFF);
  // Πράσινο για σωστό
  static const Color correct = Color(0xFF2E7D32);
  // Κόκκινο για λάθος
  static const Color wrong = Color(0xFFC62828);
  // Γκρι για disabled
  static const Color disabled = Color(0xFF9E8A6A);
}
