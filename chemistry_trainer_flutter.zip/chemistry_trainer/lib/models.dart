// ============================================================
// MODELS — ίδια δομή με Biology Trainer
// ============================================================

class Chapter {
  final String id;
  final String title;
  final String subtitle;
  final String section;
  final String file;
  final int questionCount;

  Chapter({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.section,
    required this.file,
    required this.questionCount,
  });

  factory Chapter.fromJson(Map<String, dynamic> json) {
    return Chapter(
      id: json['id'],
      title: json['title'],
      subtitle: json['subtitle'],
      section: json['section'],
      file: json['file'],
      questionCount: json['question_count'],
    );
  }
}

class Question {
  final String id;
  final String type; // 'single_choice' | 'true_false'
  final String difficulty;
  final int points;
  final List<String> tags;
  final String learningObjective;
  final String question;
  final List<Option>? options; // null για true_false
  final CorrectAnswer correctAnswer;
  final String explanation;
  final String commonMistake;
  final String source;

  Question({
    required this.id,
    required this.type,
    required this.difficulty,
    required this.points,
    required this.tags,
    required this.learningObjective,
    required this.question,
    this.options,
    required this.correctAnswer,
    required this.explanation,
    required this.commonMistake,
    required this.source,
  });

  factory Question.fromJson(Map<String, dynamic> json) {
    List<Option>? opts;
    if (json['options'] != null) {
      opts = (json['options'] as List)
          .map((o) => Option.fromJson(o))
          .toList();
    }
    return Question(
      id: json['id'],
      type: json['type'],
      difficulty: json['difficulty'],
      points: json['points'],
      tags: List<String>.from(json['tags'] ?? []),
      learningObjective: json['learning_objective'] ?? '',
      question: json['question'],
      options: opts,
      correctAnswer: CorrectAnswer.fromJson(json['correct_answer']),
      explanation: json['explanation'] ?? '',
      commonMistake: json['common_mistake'] ?? '',
      source: json['source'] ?? '',
    );
  }
}

class Option {
  final String id;
  final String text;

  Option({required this.id, required this.text});

  factory Option.fromJson(Map<String, dynamic> json) {
    return Option(id: json['id'], text: json['text']);
  }
}

class CorrectAnswer {
  final String type; // 'option' | 'boolean'
  final dynamic value; // String (A/B/C/D) | bool

  CorrectAnswer({required this.type, required this.value});

  factory CorrectAnswer.fromJson(Map<String, dynamic> json) {
    return CorrectAnswer(type: json['type'], value: json['value']);
  }

  bool isCorrect(dynamic userAnswer) {
    return value.toString() == userAnswer.toString();
  }
}

class QuizResult {
  final String chapterId;
  final int totalQuestions;
  int correctAnswers;
  int wrongAnswers;
  DateTime completedAt;

  QuizResult({
    required this.chapterId,
    required this.totalQuestions,
    this.correctAnswers = 0,
    this.wrongAnswers = 0,
    DateTime? completedAt,
  }) : completedAt = completedAt ?? DateTime.now();

  double get percentage =>
      totalQuestions > 0 ? (correctAnswers / totalQuestions) * 100 : 0;
}
